
extern void set_timer(int);
extern int get_timer(void);
extern int get_sec_ticks(void);

#define TICKS_SEC get_sec_ticks()
