STRUCT
    /n FIELD slof-dev>udev
    /l FIELD slof-dev>port
    /l FIELD slof-dev>devaddr
    /l FIELD slof-dev>hcitype
    /l FIELD slof-dev>num
    /l FIELD slof-dev>devtype
CONSTANT slof-usb-dev
