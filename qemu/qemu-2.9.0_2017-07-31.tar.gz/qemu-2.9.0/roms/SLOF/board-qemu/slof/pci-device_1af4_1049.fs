
\ Device ID 1049 is for virtio-9p non-transitional device.
\ Include the driver for virtio-9p
s" pci-device_1af4_1009.fs" included
